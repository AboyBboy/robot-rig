import bpy
from bpy.types import Panel

def main(context, object, side):
    if side == 'left':
        bpy.ops.pose.select_all(action='DESELECT')
        object['leg.target.l'].select = True
        bpy.ops.object.ground_selected()
        
    if side == 'right':
        bpy.ops.pose.select_all(action='DESELECT')
        object['leg.target.r'].select = True
        bpy.ops.object.ground_selected()


class GroundFoot(bpy.types.Operator):
    """Ground Foot"""
    bl_idname = "rig.ground_foot"
    bl_label = "Ground Foot"
    
    side = bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        main(context, bpy.data.armatures['Robot'].bones, self.side)
        return {'FINISHED'}

def register():
    bpy.utils.register_module(__name__)


def unregister():
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()