import bpy
from bpy.types import Panel

class View3DPanel:
	bl_space_type = 'VIEW_3D'
	bl_region_type = 'TOOLS'

class TorsoPanel(View3DPanel, Panel):
	bl_label = "Torso Controls"
	bl_idname = "PT_TorsoPanel"
	bl_space_type = "VIEW_3D"
	bl_region_type = "TOOLS"
	bl_category = "Rig"
	
	def draw(self, context):
		bones = context.scene.objects['Robot_Rig'].pose.bones
		
		layout = self.layout
		
		#body
		cf = layout.column_flow(columns=2)
		
		box = cf.box()
		box.label(text='Root')
		box.prop(bones['root'], 'rotation_euler', 'Rotation')
		box.prop(bones['root'], 'location')
		
		box = cf.box()
		box.label(text='Torso')
		box.prop(bones['torso'], 'rotation_euler', 'Rotation')
		box.prop(bones['torso'], 'location')
		
class ArmPanel(View3DPanel, Panel):
	bl_label = "Arm Controls"
	bl_idname = "PT_ArmPanel"
	bl_space_type = "VIEW_3D"
	bl_region_type = "TOOLS"
	bl_category = "Rig"
	
	def draw(self, context):
		bones = context.scene.objects['Robot_Rig'].pose.bones
		
		layout = self.layout
		
		# arms
		cf = layout.column_flow(columns=2)
		
		box = cf.box()
		box.label(text='Left Arm')
		box.prop(bones['arm.target.l'], 'location', 'Target')
		box.prop(bones['arm.pole.l'], 'location', 'Pole')
		
		box = cf.box()
		box.label(text='Right Arm')
		box.prop(bones['arm.target.r'], 'location', 'Target')
		box.prop(bones['arm.pole.r'], 'location', 'Pole')
		
class HandPanel(View3DPanel, Panel):
	bl_label = "Hand Controls"
	bl_idname = "PT_HandPanel"
	bl_space_type = "VIEW_3D"
	bl_region_type = "TOOLS"
	bl_category = "Rig"
	
	def draw(self, context):
		bones = context.scene.objects['Robot_Rig'].pose.bones
		
		layout = self.layout
		
		#hands
		cf = layout.column_flow(columns=2)
		
		box = cf.box()
		box.label(text='Left Hand')
		box.prop(bones['arm.hand.l'], 'rotation_euler', 'wrist rotation')
		box.prop(bones['arm.fingers.l'], 'rotation_euler', 'finger rotation')
		box.prop(bones['arm.thumb.upper.r'], 'rotation_euler', 'thumb rotation')
		
		box = cf.box()
		box.label(text='Right Hand')
		box.prop(bones['arm.hand.r'], 'rotation_euler', 'wrist rotation')
		box.prop(bones['arm.fingers.r'], 'rotation_euler', 'finger rotation')
		box.prop(bones['arm.thumb.upper.r'], 'rotation_euler', 'thumb rotation')
		
		
		
class LegPanel(View3DPanel, Panel):
	bl_label = "Leg Controls"
	bl_idname = "PT_LegPanel"
	bl_space_type = "VIEW_3D"
	bl_region_type = "TOOLS"
	bl_category = "Rig"
	
	def draw(self, context):
		bones = context.scene.objects['Robot_Rig'].pose.bones
		
		layout = self.layout
		
		#legs
		cf = layout.column_flow(columns=2)
		
		box = cf.box()
		box.label(text='Left Foot')
		box.operator("rig.ground_foot", text='Ground').side = 'left'
		box.prop(bones['leg.target.l'], 'location')
		box.prop(bones['leg.pole.l'], 'location', 'Pole')
		
		box = cf.box()
		box.label(text='Right Foot')
		box.operator("rig.ground_foot", text='Ground').side = 'right'
		box.prop(bones['leg.target.r'], 'location')
		box.prop(bones['leg.pole.r'], 'location', 'Pole')

def register():
	bpy.utils.register_module(__name__)
	
	
def unregister():
	bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()