import os

bl_info = {
	"name": "Robot Rig Controls",
	"author": "Aidan",
	"blender": (2, 79, 0),
	"category": "Object",
	"location": "3dView Panel",
	"description": "Controls for Robot Rig",
	"warning": "",
	"doc_url": "",
	"tracker_url": "",
}

modules = (
	'ground_selected',
	'robot_rig_controls',
	'robot_rig_operators'
)

os.system('cls')

if 'bpy' in locals():
	import importlib
	for x in modules:
		exec("importlib.reload({mod})".format(mod=x))
	print("reloaded multifiles")
else:
	for x in modules:
		exec("from . import {mod}".format(mod=x))
	print("imported multifiles")

import bpy
from bpy.props import *

# register

def register():
	print ("Registering ", __name__)
	bpy.utils.register_module(__name__, verbose=True)
	
def unregister():
	
	print ("Unregistering ", __name__)
	bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
	register()