import bpy

def main(context):
    x = bpy.context.scene.cursor_location.x
    y = bpy.context.scene.cursor_location.y
    z = bpy.context.scene.cursor_location.z
    
    bpy.ops.view3d.snap_cursor_to_selected()
    bpy.context.scene.cursor_location.z = 0
    
    bpy.ops.view3d.snap_selected_to_cursor()
    bpy.context.scene.cursor_location = (x, y, z)


class GroundSelected(bpy.types.Operator):
    """Sets Global Z coordinate of selection to 0"""
    bl_idname = "object.ground_selected"
    bl_label = "Ground Selected"
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        return context.active_object is not None

    def execute(self, context):
        main(context)
        return {'FINISHED'}


def register():
    bpy.utils.register_module(__name__)


def unregister():
    bpy.utils.unregister_module(__name__)


if __name__ == "__main__":
    register()